class KeystoneAuthException(Exception):
    """ Generic error class to identify and catch our own errors. """
    pass
