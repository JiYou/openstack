# A test file for HTML reporting by coverage.

if 1 < 2:
    # Needed a < to look at HTML entities.
    a = 3
else:
    a = 4
