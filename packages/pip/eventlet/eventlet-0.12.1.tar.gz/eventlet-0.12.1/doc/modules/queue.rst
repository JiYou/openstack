:mod:`queue` -- Queue class
========================================

.. automodule:: eventlet.queue
	:members:
