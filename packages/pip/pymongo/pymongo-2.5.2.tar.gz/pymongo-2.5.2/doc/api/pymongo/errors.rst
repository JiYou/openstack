:mod:`errors` -- Exceptions raised by the :mod:`pymongo` package
================================================================

.. automodule:: pymongo.errors
   :synopsis: Exceptions raised by the pymongo package
   :members:
