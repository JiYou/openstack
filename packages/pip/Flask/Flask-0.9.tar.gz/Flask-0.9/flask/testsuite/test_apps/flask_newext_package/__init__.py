ext_id = 'newext_package'
