def test():
    pass

def test_fails():
    assert False, "This test fails"
