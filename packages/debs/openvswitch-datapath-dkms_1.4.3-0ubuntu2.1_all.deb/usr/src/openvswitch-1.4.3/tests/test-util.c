/*
 * Copyright (c) 2011, 2012 Nicira Networks.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <config.h>

#include <inttypes.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

#include "command-line.h"
#include "random.h"
#include "util.h"

static void
check_log_2_floor(uint32_t x, int n)
{
    if (log_2_floor(x) != n) {
        fprintf(stderr, "log_2_floor(%"PRIu32") is %d but should be %d\n",
                x, log_2_floor(x), n);
        abort();
    }
}

static void
test_log_2_floor(int argc OVS_UNUSED, char *argv[] OVS_UNUSED)
{
    int n;

    for (n = 0; n < 32; n++) {
        /* Check minimum x such that f(x) == n. */
        check_log_2_floor(1 << n, n);

        /* Check maximum x such that f(x) == n. */
        check_log_2_floor((1 << n) | ((1 << n) - 1), n);

        /* Check a random value in the middle. */
        check_log_2_floor((random_uint32() & ((1 << n) - 1)) | (1 << n), n);
    }

    /* log_2_floor(0) is undefined, so don't check it. */
}

static void
check_ctz(uint32_t x, int n)
{
    if (ctz(x) != n) {
        fprintf(stderr, "ctz(%"PRIu32") is %d but should be %d\n",
                x, ctz(x), n);
        abort();
    }
}

static void
test_ctz(int argc OVS_UNUSED, char *argv[] OVS_UNUSED)
{
    int n;

    for (n = 0; n < 32; n++) {
        /* Check minimum x such that f(x) == n. */
        check_ctz(1 << n, n);

        /* Check maximum x such that f(x) == n. */
        check_ctz(UINT32_MAX << n, n);

        /* Check a random value in the middle. */
        check_ctz((random_uint32() | 1) << n, n);
    }

    /* Check ctz(0). */
    check_ctz(0, 32);
}

static void
test_follow_symlinks(int argc, char *argv[])
{
    int i;

    for (i = 1; i < argc; i++) {
        char *target = follow_symlinks(argv[i]);
        puts(target);
        free(target);
    }
}

static const struct command commands[] = {
    {"ctz", 0, 0, test_ctz},
    {"log_2_floor", 0, 0, test_log_2_floor},
    {"follow-symlinks", 1, INT_MAX, test_follow_symlinks},
    {NULL, 0, 0, NULL},
};

int
main(int argc, char *argv[])
{
    set_program_name(argv[0]);
    run_command(argc - 1, argv + 1, commands);
    return 0;
}
