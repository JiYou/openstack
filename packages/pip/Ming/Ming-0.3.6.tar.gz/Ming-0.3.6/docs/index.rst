.. Ming documentation master file, created by
   sphinx-quickstart on Thu Nov 19 19:51:17 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Ming's documentation!
================================

Contents:

.. toctree::
   :maxdepth: 2
   :glob:

   news   
   tour
   odm
   api/*

Miscellaneous Links of Interest
===============================

`Ming Presentation at PyAtl January 2010 <http://files.meetup.com/127119/MingPresentation.pdf>`_
    Presentation given at Python Atlanta User Group by Rick Copeland in January 2010.
   
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

