
from numpy.oldnumeric.ma import *
