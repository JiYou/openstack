# Used in the tests for run_python_module
import sys
print("runmod2: passed %s" % sys.argv[1])
