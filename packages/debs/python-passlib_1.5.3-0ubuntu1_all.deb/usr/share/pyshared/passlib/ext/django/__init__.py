"""passlib.ext.django - Django app to monkeypatch better password hashing into django

.. warning::

    This code is experimental and subject to change,
    and not officially documented in Passlib just yet
    (though it should work).

see the Passlib documentation for details on how to use this app
"""
