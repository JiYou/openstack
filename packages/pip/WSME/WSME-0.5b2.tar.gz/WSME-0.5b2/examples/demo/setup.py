from setuptools import setup

setup(name='demo',
    install_requires=[
        'WSME',
        'Bottle',
        'Pygments',
    ],
    package=['demo'])
