:mod:`ming` module
==================


.. automodule:: ming


Functions
----------

.. autofunction:: configure


