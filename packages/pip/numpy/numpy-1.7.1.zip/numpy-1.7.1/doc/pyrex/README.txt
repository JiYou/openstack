WARNING: this code is deprecated and slated for removal soon.  See the
doc/cython directory for the replacement, which uses Cython (the actively
maintained version of Pyrex).
