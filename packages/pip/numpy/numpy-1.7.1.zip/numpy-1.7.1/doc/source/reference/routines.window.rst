Window functions
================

.. currentmodule:: numpy

Various windows
---------------

.. autosummary::
   :toctree: generated/

   bartlett
   blackman
   hamming
   hanning
   kaiser
