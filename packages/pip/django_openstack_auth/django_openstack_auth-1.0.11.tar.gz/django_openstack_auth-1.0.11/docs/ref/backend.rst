==================
The Backend Module
==================

.. automodule:: openstack_auth.backend
   :members:
