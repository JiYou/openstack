API Reference
=============

.. toctree::
   :maxdepth: 1
   
   backup_schedules
   exceptions
   flavors
   images
   ipgroups
   servers